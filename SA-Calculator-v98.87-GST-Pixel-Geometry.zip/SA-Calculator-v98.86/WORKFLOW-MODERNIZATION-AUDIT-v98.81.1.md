# SA Calculator v98.81.1 — Android Workflow Modernization Audit

## Findings

The app source already passed its 89-test release suite, JavaScript syntax checks, web-bundle build, and root-to-`www/` byte comparison. The workflow still referenced older major releases for three official GitHub Actions. These were modernized without changing the calculator runtime or release identity.

## Changes

- `actions/cache@v4` → `actions/cache@v6` (Node.js 24 runtime).
- `actions/setup-java@v5` → `actions/setup-java@v6`. Java remains pinned to Temurin 21.
- `actions/upload-artifact@v4` → `actions/upload-artifact@v7` (Node.js 24 runtime).
- Kept `actions/checkout@v7`, `actions/setup-node@v7`, `gradle/actions/setup-gradle@v6`, and `android-actions/setup-android@v4`.
- Applied identical changes to the repository workflow, the packaged standalone workflow, and the separately supplied YAML.
- Updated regression checks to enforce the selected action majors and workflow-copy parity.

## Validation boundaries

The YAML parses, the workflow copies are byte-identical, and local release tests pass. A GitHub-hosted Actions run is still required to verify action resolution and the Android SDK/Gradle/APK steps. No Android SDK or generated native Android project was present in the supplied archive, so a signed or debug APK was not built locally. Physical-device touch, rendering, and performance checks also remain outside this environment.

## Official action references

- https://github.com/actions/cache
- https://github.com/actions/setup-java
- https://github.com/actions/upload-artifact
- https://github.com/actions/setup-node
- https://github.com/android-actions/setup-android
