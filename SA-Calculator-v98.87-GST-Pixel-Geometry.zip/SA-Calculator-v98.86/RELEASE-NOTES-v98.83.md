# SA Calculator v98.83 — GST field boundary cleanup

## Changes
- Removed decorative outer borders, outlines, shadows and card surfaces from the GST amount/rate entry containers.
- Removed the inset border/background from both GST editable value fields.
- Forced amount and GST rate text/caret alignment to start at the left edge (LTR), including while typing.
- Removed decorative borders/outlines from the quick-rate and GST segmented controls while retaining their filled active/inactive states.
- Hid the duplicate native GST mode selector; the visible With GST / Without GST segmented control remains the single visible mode control.
- Kept the shared numeric keypad, GST calculations, state split logic, rate validation, and result lifecycle unchanged.
- Added responsive narrow-screen field geometry and a dedicated GST UI regression test.

## Release identity
- Package/PWA version: `1.98.97-v98.83`
- Android versionCode: `1099103`
- Service worker cache: `sa-calculator-v98-83-gst-clean-ui-v9883`
