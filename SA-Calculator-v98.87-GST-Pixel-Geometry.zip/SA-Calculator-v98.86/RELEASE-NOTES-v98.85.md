# SA Calculator v98.85 — Tool layers and cursor correction

- Unified Tools launcher and numeric-tool workspaces to a white/light surface without changing the app-wide theme preference.
- Replaced dark field/card/keypad surfaces in supported tool screens with white surfaces and consistent contrast.
- Added tap-position caret placement for shared numeric tool fields, plus insertion and backspace at the selected position.
- Kept cursor visible within formatted input text rather than forcing it to the end of the field.
- Unit category chips remain inline; legacy hidden category form/back layer is suppressed.
- Removed the duplicate visible Unit Converter swap control; the shared keypad action remains the single unit-swap action.
- Currency conversion remains live; its keypad action is now Calculate/refresh rather than a redundant swap arrow.
- Preserved currency pair selectors, unit selectors, GST/finance calculation engines and existing tool registrations.
